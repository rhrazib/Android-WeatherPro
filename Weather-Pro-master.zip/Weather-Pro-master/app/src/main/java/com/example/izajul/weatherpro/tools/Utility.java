package com.example.izajul.weatherpro.tools;

import com.example.izajul.weatherpro.R;

/**
 * Created by izajul on 1/24/2017.
 */

public class Utility {


    public int setImageResource(String code){
        if (code.equals("0")){
            return R.drawable.a0;
        }else if(code.equals("1")){
            return R.drawable.a1;
        }else if(code.equals("2")){
            return R.drawable.a2;
        }else if(code.equals("3")){
            return R.drawable.a3;
        }else if(code.equals("4")){
            return R.drawable.a4;
        }else if(code.equals("5")){
            return R.drawable.a5;
        }else if(code.equals("6")){
            return R.drawable.a6;
        }else if(code.equals("7")){
            return R.drawable.a7;
        }else if(code.equals("8")){
            return R.drawable.a8;
        }else if(code.equals("9")){
            return R.drawable.a9;
        }else if(code.equals("10")){
            return R.drawable.a10;
        }else if(code.equals("11")){
            return R.drawable.a11;
        }else if(code.equals("12")){
            return R.drawable.a12;
        }else if(code.equals("13")){
            return R.drawable.a13;
        }else if(code.equals("14")){
            return R.drawable.a14;
        }else if(code.equals("15")){
            return R.drawable.a15;
        }else if(code.equals("16")){
            return R.drawable.a16;
        }else if(code.equals("17")){
            return R.drawable.a17;
        }else if(code.equals("18")){
            return R.drawable.a18;
        }else if(code.equals("19")){
            return R.drawable.a19;
        }else if(code.equals("20")){
            return R.drawable.a20;
        }else if(code.equals("21")){
            return R.drawable.a21;
        }else if(code.equals("22")){
            return R.drawable.a22;
        }else if(code.equals("23")){
            return R.drawable.a23;
        }else if(code.equals("24")){
            return R.drawable.a24;
        }else if(code.equals("25")){
            return R.drawable.a25;
        }else if(code.equals("26")){
            return R.drawable.a26;
        }else if(code.equals("27")){
            return R.drawable.a27;
        }else if(code.equals("28")){
            return R.drawable.a28;
        }else if(code.equals("29")){
            return R.drawable.a29;
        }else if(code.equals("30")){
            return R.drawable.a30;
        }else if(code.equals("31")){
            return R.drawable.a31;
        }else if(code.equals("32")){
            return R.drawable.a32;
        }else if(code.equals("33")){
            return R.drawable.a33;
        }else if(code.equals("34")){
            return R.drawable.a34;
        }else if(code.equals("35")){
            return R.drawable.a35;
        }else if(code.equals("36")){
            return R.drawable.a36;
        }else if(code.equals("37")){
            return R.drawable.a37;
        }else if(code.equals("38")){
            return R.drawable.a38;
        }else if(code.equals("39")){
            return R.drawable.a39;
        }else if(code.equals("40")){
            return R.drawable.a40;
        }else if(code.equals("41")){
            return R.drawable.a41;
        }else if(code.equals("42")){
            return R.drawable.a42;
        }else if(code.equals("43")){
            return R.drawable.a43;
        }else if(code.equals("44")){
            return R.drawable.a26;
        }else if(code.equals("45")){
            return R.drawable.a45;
        }else if(code.equals("46")){
            return R.drawable.a46;
        }else if(code.equals("47")){
            return R.drawable.a47;
        }else {
            return R.drawable.na;
        }
    }
}
